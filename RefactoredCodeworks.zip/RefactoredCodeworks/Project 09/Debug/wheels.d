# FIXED

wheels.obj: ../wheels.c
wheels.obj: C:/ti/ccs1280/ccs/ccs_base/msp430/include/msp430.h
wheels.obj: C:/ti/ccs1280/ccs/ccs_base/msp430/include/msp430fr2355.h
wheels.obj: C:/ti/ccs1280/ccs/ccs_base/msp430/include/in430.h
wheels.obj: C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics.h
wheels.obj: C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics_legacy_undefs.h
wheels.obj: C:/ti/ccs1280/ccs/ccs_base/msp430/include/legacy.h
wheels.obj: ../functions.h
wheels.obj: ../LCD.h
wheels.obj: ../ports.h
wheels.obj: ../macros.h
wheels.obj: C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/strings.h
wheels.obj: C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/string.h
wheels.obj: C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_ti_config.h
wheels.obj: C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/linkage.h
wheels.obj: C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/cdefs.h
wheels.obj: C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/xlocale/_string.h
wheels.obj: ../wheels.h
wheels.obj: ../Timers.h
wheels.obj: ../switches.h

../wheels.c:

C:/ti/ccs1280/ccs/ccs_base/msp430/include/msp430.h:

C:/ti/ccs1280/ccs/ccs_base/msp430/include/msp430fr2355.h:

C:/ti/ccs1280/ccs/ccs_base/msp430/include/in430.h:

C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics.h:

C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics_legacy_undefs.h:

C:/ti/ccs1280/ccs/ccs_base/msp430/include/legacy.h:

../functions.h:

../LCD.h:

../ports.h:

../macros.h:

C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/strings.h:

C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/string.h:

C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_ti_config.h:

C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/linkage.h:

C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/cdefs.h:

C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/xlocale/_string.h:

../wheels.h:

../Timers.h:

../switches.h:

