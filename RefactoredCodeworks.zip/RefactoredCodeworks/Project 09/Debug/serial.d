# FIXED

serial.obj: ../serial.c
serial.obj: C:/ti/ccs1280/ccs/ccs_base/msp430/include/msp430.h
serial.obj: C:/ti/ccs1280/ccs/ccs_base/msp430/include/msp430fr2355.h
serial.obj: C:/ti/ccs1280/ccs/ccs_base/msp430/include/in430.h
serial.obj: C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics.h
serial.obj: C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics_legacy_undefs.h
serial.obj: C:/ti/ccs1280/ccs/ccs_base/msp430/include/legacy.h
serial.obj: ../functions.h
serial.obj: ../LCD.h
serial.obj: ../ports.h
serial.obj: ../macros.h
serial.obj: C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/strings.h
serial.obj: C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/string.h
serial.obj: C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_ti_config.h
serial.obj: C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/linkage.h
serial.obj: C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/cdefs.h
serial.obj: C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/xlocale/_string.h
serial.obj: ../wheels.h
serial.obj: ../Timers.h
serial.obj: ../switches.h

../serial.c:

C:/ti/ccs1280/ccs/ccs_base/msp430/include/msp430.h:

C:/ti/ccs1280/ccs/ccs_base/msp430/include/msp430fr2355.h:

C:/ti/ccs1280/ccs/ccs_base/msp430/include/in430.h:

C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics.h:

C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics_legacy_undefs.h:

C:/ti/ccs1280/ccs/ccs_base/msp430/include/legacy.h:

../functions.h:

../LCD.h:

../ports.h:

../macros.h:

C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/strings.h:

C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/string.h:

C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_ti_config.h:

C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/linkage.h:

C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/cdefs.h:

C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/xlocale/_string.h:

../wheels.h:

../Timers.h:

../switches.h:

