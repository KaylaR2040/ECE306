# FIXED

adc_interrupts.obj: ../adc_interrupts.c

../adc_interrupts.c:

