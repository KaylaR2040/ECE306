################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
CMD_SRCS += \
../lnk_msp430fr2355.cmd 

C_SRCS += \
../ADC.c \
../DAC.c \
../Display.c \
../IOT.c \
../Ports_Interrupts.c \
../StateMachine.c \
../Switches.c \
../Timer_Interrupts.c \
../Timers.c \
../clocks.c \
../init.c \
../led.c \
../main.c \
../ports.c \
../serial.c \
../system.c \
../wheels.c 

C_DEPS += \
./ADC.d \
./DAC.d \
./Display.d \
./IOT.d \
./Ports_Interrupts.d \
./StateMachine.d \
./Switches.d \
./Timer_Interrupts.d \
./Timers.d \
./clocks.d \
./init.d \
./led.d \
./main.d \
./ports.d \
./serial.d \
./system.d \
./wheels.d 

OBJS += \
./ADC.obj \
./DAC.obj \
./Display.obj \
./IOT.obj \
./Ports_Interrupts.obj \
./StateMachine.obj \
./Switches.obj \
./Timer_Interrupts.obj \
./Timers.obj \
./clocks.obj \
./init.obj \
./led.obj \
./main.obj \
./ports.obj \
./serial.obj \
./system.obj \
./wheels.obj 

OBJS__QUOTED += \
"ADC.obj" \
"DAC.obj" \
"Display.obj" \
"IOT.obj" \
"Ports_Interrupts.obj" \
"StateMachine.obj" \
"Switches.obj" \
"Timer_Interrupts.obj" \
"Timers.obj" \
"clocks.obj" \
"init.obj" \
"led.obj" \
"main.obj" \
"ports.obj" \
"serial.obj" \
"system.obj" \
"wheels.obj" 

C_DEPS__QUOTED += \
"ADC.d" \
"DAC.d" \
"Display.d" \
"IOT.d" \
"Ports_Interrupts.d" \
"StateMachine.d" \
"Switches.d" \
"Timer_Interrupts.d" \
"Timers.d" \
"clocks.d" \
"init.d" \
"led.d" \
"main.d" \
"ports.d" \
"serial.d" \
"system.d" \
"wheels.d" 

C_SRCS__QUOTED += \
"../ADC.c" \
"../DAC.c" \
"../Display.c" \
"../IOT.c" \
"../Ports_Interrupts.c" \
"../StateMachine.c" \
"../Switches.c" \
"../Timer_Interrupts.c" \
"../Timers.c" \
"../clocks.c" \
"../init.c" \
"../led.c" \
"../main.c" \
"../ports.c" \
"../serial.c" \
"../system.c" \
"../wheels.c" 


