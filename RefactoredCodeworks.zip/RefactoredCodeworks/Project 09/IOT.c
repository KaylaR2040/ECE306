// ///*
// // * IOT.c
// // *
// // *  Created on: Apr 2, 2025
// // *      Author: price
// // */

// #include  "msp430.h"
// #include  "functions.h"
// #include  "LCD.h"
// #include  "ports.h"
// #include  "macros.h"
// #include "strings.h"
// #include "wheels.h"
// #include "Timers.h"
// #include  "DAC.h"
// #include "switches.h"

// //IOT COMMUNICATION TYPE STUFF
// volatile char stop_save_sett[] = "AT+SYSSTORE=0\r\n";
// volatile char update_conn_sett[] = "AT+CIPMUX=1\r\n";
// volatile char conf_server[] = "AT+CIPSERVER=1,8080\r\n";
// volatile char SSID_access[] = "AT+CWJAP?\r\n";
// volatile char IP_access[] = "AT+CIFSR\r\n";
// volatile char check_okay[] = "AT\r\n";
// volatile char pinging1[] = "AT+PING=\"www.google.com\"\r\n";
// volatile char pinging2[] = "AT+PING=\"www.ncsu.edu\"\r\n";
// //char pin[] = "0819";
// extern char pin[] = "3061";


// volatile char IOT_Ring_Rx[LARGE_RING_SIZE];
// volatile char iot_TX_buf[LARGE_RING_SIZE];
// volatile char ssid_display[SSID_SIZE];
// volatile unsigned int tx_index;
// unsigned int command4_flag;
// volatile char ip_display1[SSID_SIZE];
// volatile char ip_display2[SSID_SIZE];
// extern unsigned int initialize_done;
// extern unsigned int run_time;
// volatile char commanding_send;
// extern unsigned int run_time_flag;

// extern unsigned int ADC_Left_Detect;
// extern unsigned int ADC_Right_Detect;
// extern unsigned int ADC_thumb;
// unsigned int on_line;
// extern unsigned int transmit_done;
// unsigned int clear_display;

// extern unsigned int iot_on_time;
// unsigned int iot_start_count;

// unsigned int response_parse;
// unsigned int movement;
// int vv;
// unsigned int setTime;

// void IOT_Process(void){
//     switch (initialize_done){
//         case 0:
//             if (iot_on_time < 15){
//                 if (iot_on_time <= 10){
//                     strcpy(display_line[0], "   IOT    ");
//                     strcpy(display_line[1], "   OFF    ");
//                     strcpy(display_line[2], "          ");
//                     strcpy(display_line[3], "          ");
//                     display_changed = TRUE;
//                 }
//                 else{
//                     P3OUT |= IOT_EN;
//                     strcpy(display_line[0], "   IOT    ");
//                     strcpy(display_line[1], "   ON     ");
//                     strcpy(display_line[2], "          ");
//                     strcpy(display_line[3], "          ");
//                     display_changed = TRUE;
//                     initial_process = 1;
//                 }
//             }

//             else if (iot_on_time < 30){
//                 vv = 1;
//             }


//             else if (iot_on_time < 50){
//                 switch (initial_process){
//                 case 1:
//                     vv = 0;
//                     strcpy(display_line[3], "    1     ");
//                     display_changed = TRUE;
//                     if (iot_TX_buf[response_parse++] == '\r'){
//                         //                        response_parse--;
//                         if (iot_TX_buf[response_parse-2] == 'P'){
//                             strcpy(IOT_Ring_Rx, stop_save_sett);
//                             UCA1IE |= UCTXIE;
//                             initial_process = 2;
//                             response_parse = 0;

//                             while (IOT_Ring_Rx[vv] == 0x00){
//                                 IOT_Ring_Rx[vv++] = 0;
//                             }
//                         }
//                     }
//                     break;
//                 case 2:
//                     vv= 0;
//                     strcpy(display_line[3], "    2     ");
//                     display_changed = TRUE;
//                     if (iot_TX_buf[response_parse++] == '\r'){
//                         if (iot_TX_buf[response_parse-2] == 'K'){
//                             tx_index = 0;
//                             strcpy(IOT_Ring_Rx, update_conn_sett);
//                             UCA1IE |= UCTXIE;
//                             initial_process = 3;
//                             response_parse = 0;
//                         }
//                     }
//                     if (response_parse > 31){
//                         response_parse = 0;
//                     }
//                     if (tx_index > 31){
//                         tx_index = 0;
//                     }
//                     break;
//                 case 3:
//                     vv= 0;
//                     strcpy(display_line[3], "    3     ");
//                     display_changed = TRUE;
//                     if (iot_TX_buf[response_parse++] == '\r'){
//                         vv = 0;
//                         if (iot_TX_buf[response_parse-10] == 'X'){
//                             tx_index = 0;
//                             strcpy(IOT_Ring_Rx, conf_server);
//                             UCA1IE |= UCTXIE;
//                             initial_process = 4;
//                             response_parse = 0;
//                         }
//                     }
//                     if (response_parse > 31){
//                         response_parse = 0;
//                     }
//                     if (tx_index > 31){
//                         tx_index = 0;
//                     }
//                     break;
//                 case 4:
//                     vv= 0;
//                     strcpy(display_line[3], "    4     ");
//                     display_changed = TRUE;
//                     if (iot_TX_buf[response_parse++] == '\r'){
//                         vv = 0;
//                         //                if (response_parse-9 < 0){
//                         if (iot_TX_buf[response_parse + 23] == '8'){
//                             tx_index = 0;
//                             strcpy(IOT_Ring_Rx, SSID_access);
//                             UCA1IE |= UCTXIE;
//                             initial_process = 5;
//                             response_parse = 0;
//                         }
//                     }
//                     if (response_parse > 31){
//                         response_parse = 0;
//                     }
//                     if (tx_index > 31){
//                         tx_index = 0;
//                     }
//                     break;
//                 case 5:
//                     // printing the ssid
//                     strcpy(display_line[3], "    5     ");
//                     display_changed = TRUE;
//                     strcpy(display_line[1], "          ");
//                     strcpy(display_line[0], "          ");
//                     strcpy(display_line[2], "          ");
//                     strcpy(display_line[3], "          ");
//                     display_changed = TRUE;
//                     initial_process = 6;
//                     break;
//                 case 6:
//                     vv= 0;
//                     strcpy(display_line[3], "    6     ");
//                     display_changed = TRUE;

//                     if (iot_TX_buf[response_parse++] == '\r'){
//                         vv = 0;
//                         if (iot_TX_buf[response_parse-9] == ','){
//                             tx_index = 0;
//                             strcpy(IOT_Ring_Rx, IP_access);
//                             UCA1IE |= UCTXIE;
//                             initial_process = 7;
//                             response_parse = 0;
//                             command4_flag = 0;
//                             //                            strcpy(display_line[1], " SSID CAP ");
//                             //                            strcpy(display_line[0], "          ");
//                             //                            display_changed = TRUE;
//                             //                            //                            strcpy(display_line[0], ssid_display);
//                             //                            strcpy(display_line[0], "ncsu      ");
//                             //                            strcpy(display_line[2], "          ");
//                             //                            strcpy(display_line[3], "          ");
//                             //                            display_changed = TRUE;
//                         }
//                     }
//                     //            }
//                     if (response_parse > 31){
//                         response_parse = 0;
//                     }
//                     if (tx_index > 31){
//                         tx_index = 0;
//                     }
//                     break;
//                 case 7:
//                     vv= 0;
//                     strcpy(display_line[3], "    7     ");
//                     display_changed = TRUE;
//                     //            if (command4_flag){
//                     if (iot_TX_buf[response_parse++] == '\r'){
//                         vv = 0;
//                         if (iot_TX_buf[response_parse-8] == '"'){
//                             tx_index = 0;
//                             strcpy(IOT_Ring_Rx, check_okay);
//                             UCA1IE |= UCTXIE;
//                             initial_process = 8;
//                             response_parse = 0;
//                             //                    command4_flag = 0;
//                             strcpy(display_line[0], "          ");
//                             strcpy(display_line[1], "          ");
//                             strcpy(display_line[2], "          ");
//                             strcpy(display_line[3], "          ");
//                             display_changed = TRUE;
//                         }
//                     }
//                     if (response_parse > 31){
//                         response_parse = 0;
//                     }
//                     if (tx_index > 31){
//                         tx_index = 0;
//                     }
//                     break;
//                 case 8:
//                     strcpy(display_line[3], "    8     ");
//                     display_changed = TRUE;
//                     initialize_done = 1;
//                     strcpy(display_line[4], "  READY!  ");
//                     display_changed = TRUE;
//                     break;



//                 }
//             }
//             break;

//         case 1:
//             pingpong();
//             vv = 0;
//             if (iot_TX_buf[response_parse++] == '^'){
//                 //            response_parse++;
//                 if(iot_TX_buf[response_parse] == pin[0] && iot_TX_buf[response_parse+1] == pin[1] && iot_TX_buf[response_parse+2] == pin[2] && iot_TX_buf[response_parse+3] == pin[3]){
//                     response_parse = response_parse +4;
//                     switch (iot_TX_buf[response_parse]){
//                     case 'F':
//                         if(!movement){
//                             setTime = (int)iot_TX_buf[response_parse+1]-'0';
//                             run_time_flag = 1;
//                             commanding_send = FORWARDS;
//                             run_time = 0;
//                             for (vv = 0; vv < 32; vv++){
//                                 iot_TX_buf[vv] = 0;
//                             }
//                         }

//                         break;
//                     case 'B':
//                         if(!movement){
//                             setTime = (int)iot_TX_buf[response_parse+1]-'0';
//                             run_time_flag = 1;
//                             commanding_send = BACK;
//                             run_time = 0;
//                             for (vv = 0; vv < 32; vv++){
//                                 iot_TX_buf[vv] = 0;
//                             }
//                         }
//                         break;
//                     case 'R':
//                         if(!movement){
//                             setTime = (int)iot_TX_buf[response_parse+1]-'0';
//                             run_time_flag = 1;
//                             commanding_send = RIGHT;
//                             run_time = 0;
//                             for (vv = 0; vv < 32; vv++){
//                                 iot_TX_buf[vv] = 0;
//                             }
//                         }
//                         break;
//                     case 'L':
//                         if(!movement){
//                             setTime = (int)iot_TX_buf[response_parse+1]-'0';
//                             run_time_flag = 1;
//                             commanding_send = LEFT;
//                             run_time = 0;
//                             for (vv = 0; vv < 32; vv++){
//                                 iot_TX_buf[vv] = 0;
//                             }
//                         }
//                         break;

//                     case 'S':
//                         if(!movement){
//                             setTime = (int)iot_TX_buf[response_parse+1]-'0';
//                             commanding_send = WAIT;
//                             run_time = 0;

//                             for (vv = 0; vv < 32; vv++){
//                                 iot_TX_buf[vv] = 0;
//                             }
//                         }
//                         break;

//                     case 'I':
//                         if(!movement){
//                             setTime = iot_TX_buf[response_parse+1];
//                             commanding_send = INTERCEPT;
//                             run_time = 0;
//                             run_time_flag = 1;
//                             init_cmd_state = 0;
//                             state = WAIT;
//                             for (vv = 0; vv < 32; vv++){
//                                 iot_TX_buf[vv] = 0;
//                             }
//                         }
//                         break;

//                     case 'A':
//                         if(!movement){
//                             setTime = 10;
//                             sheet = iot_TX_buf[response_parse+1];
//                             commanding_send = ARRIVED;
//                             run_time = 0;

//                             for (vv = 0; vv < 32; vv++){
//                                 iot_TX_buf[vv] = 0;
//                             }
//                         }
//                         break;

//                     case 'C':
//                         if(!movement){
//                             setTime = 10;
//                             ir_setting = (int)iot_TX_buf[response_parse+1]-'0'; // 0=Clear Config, 1=Set Black Low, 2=Set Black High
//                             commanding_send = IRCONF;
//                             run_time = 0;
//                             ir_first = TRUE;

//                             for (vv = 0; vv < 32; vv++){
//                                 iot_TX_buf[vv] = 0;
//                             }
//                         }
//                         break;


//                     case 'e':
//                         // DANGER WARNING
//                         if(!movement){
//                             setTime = (int)iot_TX_buf[response_parse+1]-'0';

//                             commanding_send = EXIT; // END
//                             run_time = 0;
//                             run_time_flag = 1;

//                             Off_Case();


//                             for (vv = 0; vv < 32; vv++){
//                                 iot_TX_buf[vv] = 0;
//                             }
//                         }

//                         break;


//                     case 's':
//                         if(!movement){
//                             setTime = (int)iot_TX_buf[response_parse+1]-'0'; // 0=Clear Config, 1=Set Black Low, 2=Set Black High
//                             commanding_send = SLOWRIGHT;
//                             run_time = 0;
//                             run_time_flag = 1;

//                             // BEFORE ARCH
//                             Off_Case();
//                             archState = 1;
//                             arch_counter = 0;

//                             for (vv = 0; vv < 32; vv++){
//                                 iot_TX_buf[vv] = 0;
//                             }
//                         }
//                         break;

//                     case 'd':
//                         if(!movement){
//                             direction = (int)iot_TX_buf[response_parse+1]-'0';
//                             setTime = 10;
//                             run_time_flag = 1;
//                             commanding_send = DIRECTION;
//                             run_time = 0;
//                             for (vv = 0; vv < 32; vv++){
//                                 iot_TX_buf[vv] = 0;
//                             }
//                         }

//                     default: break;
//                     } // END of switch (iot_TX_buf[response_parse])


//                 } // End of PIN If statement
//             } // End of if (iot_TX_buf[response_parse++] == '^')

//             if (response_parse > 31) {
//                 response_parse = 0;
//             }

//             char tempStr[10];
//             switch (commanding_send){
//             case WAIT:
//                 displayclr = 0;
//                 motor_off();
//                 // Unsure why this if statement exists, value always seems to be < 50
//                 if (run_time < 50){
//                     dispPrint(ssid_display, '1');
//                     dispPrint("IP address", '2');
//                     dispPrint(ip_display1, '3');
//                     dispPrint(ip_display2, '4');

//                     display_changed = TRUE;
//                 }else{                 // Commented out because I don't see the use of it
//                     strcpy(display_line[1], " WAITDONE ");
//                     strcpy(display_line[3], "         W");
//                     display_changed = TRUE;
//                     //                run_time = 0;
//                 }

//                 break;
            
//             case FORWARDS:
//                 //                motor_run_forward();
//                 // new_forward();
//                 // move_test(setTime);
//                 move_test(5); // Move Forwards
//                 strcpy(tempStr,ip_display2);
//                 strcat(tempStr,"F");
//                 dispPrint(tempStr, '4');
//                 display_changed = TRUE;
//                 if (run_time > setTime){ // was originally 10
//                     run_time_flag = 0;
//                     motor_off();
//                     run_time = 0;
//                     commanding_send = WAIT;
//                     movement = 0;
//                 }
//                 break;
//             case BACK:
//                 //                motor_run_backward();
//                 // new_backward();
//                 move_test(6); // Move Backwards
//                 strcpy(tempStr,ip_display2);
//                 strcat(tempStr,"B");
//                 dispPrint(tempStr, '4');
//                 display_changed = TRUE;
//                 if (run_time > setTime){
//                     run_time_flag = 0;
//                     motor_off();
//                     run_time = 0;
//                     commanding_send = WAIT;
//                     movement = 0;
//                     strcpy(display_line[0],"  BL STOP ");
//                     strcpy(display_line[1],"D-DAY OVER");
//                     display_changed = TRUE;
//                 }
//                 break;
//             case RIGHT:
//                 motor_run_right();
//                 strcpy(tempStr,ip_display2);
//                 strcat(tempStr,"R");
//                 dispPrint(tempStr, '4');
//                 display_changed = TRUE;
//                 display_changed = TRUE;
//                 if (run_time >= setTime){
//                     run_time_flag = 0;
//                     motor_off();
//                     run_time = 0;
//                     commanding_send = WAIT;
//                     movement = 0;
//                 }
//                 break;
//             case LEFT:
//                 motor_run_left();
//                 strcpy(tempStr,ip_display2);
//                 strcat(tempStr,"L");
//                 dispPrint(tempStr, '4');
//                 display_changed = TRUE;
//                 if (run_time >= setTime){
//                     run_time_flag = 0;
//                     motor_off();
//                     run_time = 0;
//                     commanding_send = WAIT;
//                     movement = 0;
//                 }

//                 break;

//             case INTERCEPT:
//                 // make the display cleared
//                 //                displayclr = displayclr +1;

//                 // Have it transmit the IR VALUES
//                 HexToBCD(ADC_Left_Detect);
//                 adc_line(2,2);

//                 HexToBCD(ADC_Right_Detect);
//                 adc_line(3,2);
//                 display_changed = TRUE;


//                 // Initial Movements (Calls Black Line State Machine After Initial Movement is Over)
//                 initialMovementBL();
//                 //                blacklinemachine();

//                 break;
//             case ARRIVED:
//                 // make the display cleared
//                 strcpy(display_line[0], "          ");
//                 display_changed = TRUE;
//                 Display_complete();
//                 if (run_time >= setTime){
//                     run_time_flag = 0;
//                     motor_off();
//                     run_time = 0;
//                     commanding_send = WAIT;
//                     movement = 0;
//                 }

//                 break;
//             case IRCONF:
//                 strcpy(display_line[0], "IR Config ");
//                 strcpy(display_line[3], "          ");
//                 display_changed = TRUE;
//                 if(ir_first){
//                     ir_conf_display();
//                     ir_first = FALSE;
//                 }
//                 if (run_time > 1){
//                     run_time_flag = 0;
//                     motor_off();
//                     run_time = 0;
//                     commanding_send = WAIT;
//                     movement = 0;
//                 }
//                 break;


//             case EXIT:
//                 // NEW DANGER WARNING
//                 strcpy(display[0],"END OF 306");
//                 strcpy(display[1],"END OF 306");
//                 strcpy(display[2],"END OF 306");
//                 //                strcpy(display[3],"END OF 306");
//                 display_changed = TRUE;

//                 new_forward();
//                 strcpy(tempStr,ip_display2);
//                 strcat(tempStr,"e");
//                 dispPrint(tempStr, '4');
//                 display_changed = TRUE;


//                 if (run_time > setTime*10){
//                     run_time_flag = 0;
//                     motor_off();
//                     run_time = 0;
//                     commanding_send = WAIT;
//                     movement = 0;
//                 }
//                 break;


//             case SLOWRIGHT:
//                 strcpy(display_line[0], "ARCH");
//                 display_changed = TRUE;

//                 dispPrint("ARCH",'1');
//                 display_changed = TRUE;

//                 arch_movement();
//                 break;
//                 //            }
//                 //              TEST INCORRECT???? COmmented out 2 lines
//                 //                default: break;
//                 //            }

//             case DIRECTION:
//                 //                motor_run_forward();
//                 // new_forward();
//                 move_test(direction);
//                 strcpy(tempStr,ip_display2);
//                 strcat(tempStr,"d");
//                 dispPrint(tempStr, '4');
//                 display_changed = TRUE;
//                 if (run_time > setTime){ // was originally 10
//                     run_time_flag = 0;
//                     motor_off();
//                     run_time = 0;
//                     commanding_send = WAIT;
//                     movement = 0;
//                 }
//                 break;


//             default: break;
//             } // switch (commanding_send)
//             break;


//             default: break;
//         } // End of switch(initialize_done)



//     } // End of while()